
//==================  this code is working correctly =============================//

// module.exports.hello = async (event) => {
//     const response = {
//         statusCode: 200, 
//         headers: {
//             "Access-Control-Allow-Origin": "*",
//         },
//         body: JSON.stringify({
//             message: "Hello, Serverless!",
//             input: event,
//         }),
//     };

//     return response;
// };

//===================== The above code is woring correctly ===========================//



module.exports.hello = async (event) => {
    // Extract name and age from the query string parameters
    const { name, age } = event.queryStringParameters;

    // Create a response message based on the extracted parameters
    const responseMessage = name && age 
        ? `Hello, ${name}! You are ${age} years old.` 
        : "Hello, Serverless!";

    // Build the response object
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*", // Allow CORS
        },
        body: JSON.stringify({
            message: responseMessage,
            input: event, // Include the full event for debugging purposes
        }),
    };

    return response;
};
